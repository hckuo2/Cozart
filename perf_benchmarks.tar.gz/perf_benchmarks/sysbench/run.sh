#!/bin/bash
./bringup.sh $1 $2 $3 $4