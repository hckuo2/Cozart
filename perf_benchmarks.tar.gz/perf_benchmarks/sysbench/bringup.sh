#!/bin/bash

run_type=$1
image=sysbench:1.0-strace
cpu=$2
profile_path=$3
run_seconds=$4


if [ "$run_type" == "docker" ];
then
	#default docker
	security=""
	name="default"

elif [ "$run_type" == "seccomp" ];
then
	#insecure seccomp
	security="--security-opt seccomp=unconfined"
	name="insecure_seccomp"

elif [ "$run_type" == "selinux" ];
then
	#insecure selinux
	security="--security-opt label:disable"
	name="insecure_selinux"

elif [ "$run_type" == "seccomp_selinux" ];
then
	#insecure seccomp + selinux
	security="--security-opt seccomp=unconfined --security-opt label:disable"
	name="insecure_seccomp_selinux"

elif [ "$run_type" == "draco_syscall" ];
then
	#draco
	security="--security-opt seccomp=""$profile_path"
	name="draco_syscall"

elif [ "$run_type" == "draco" ];
then
	#draco
	security="--security-opt seccomp=""$profile_path"
	name="draco"
else
	echo "run type $run_type not found"
	echo "Supported run types are: docker, seccomp, selinux, seccomp_selinux, draco_syscall, draco"
	exit
fi

docker run --cpuset-cpus=$cpu  --name strace-sysbench-$name -e RUN_TIME=$run_seconds $security --rm   -d  $image 
