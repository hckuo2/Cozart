#!/bin/sh
sysbench fileio --file-num=128 --file-block-size=256 --file-total-size=512MB --file-test-mode=rndrd run