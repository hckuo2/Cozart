#!/bin/sh
docker build -t sysbench:1.0-strace -f Dockerfile.sysbench .
