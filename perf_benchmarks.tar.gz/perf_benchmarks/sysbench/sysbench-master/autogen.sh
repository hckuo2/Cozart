#!/bin/sh

autoreconf -vi
